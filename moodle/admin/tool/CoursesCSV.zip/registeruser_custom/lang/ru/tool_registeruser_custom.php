<?php

$string['coursefile'] = 'Файл для загрузки';
$string['upload'] = 'Загрузить';
$string['registeruser_custom'] = 'Прикрепление курсов к пользователям CSV';
$string['registeruser'] = 'Прикрепление курсов к пользователям CSV';