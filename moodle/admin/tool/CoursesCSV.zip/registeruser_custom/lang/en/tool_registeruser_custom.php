<?php


$string['coursefile'] = 'File to upload';
$string['upload'] = 'Upload';
$string['registeruser'] = 'Attach courses to user using CSV';
$string['registeruser_custom'] = 'Attach courses to user using CSV';