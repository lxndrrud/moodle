<?php


$string['coursefile'] = 'File to upload';
$string['upload'] = 'Upload';
$string['csvcoursesattaching'] = 'Attach courses to user using CSV';