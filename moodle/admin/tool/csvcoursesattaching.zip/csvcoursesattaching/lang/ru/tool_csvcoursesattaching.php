<?php

$string['coursefile'] = 'Файл для загрузки';
$string['upload'] = 'Загрузить';
$string['csvcoursesattaching'] = 'Прикрепление курсов к пользователям CSV';